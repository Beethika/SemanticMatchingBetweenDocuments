package DocSimilarity;

public final class Debug 
{
	public static final boolean ON= false;
}
