package DocSimilarity;

public class Edge
{
	int word2;
	float weight;
}
