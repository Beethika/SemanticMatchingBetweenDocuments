package DocSimilarity;

class Heap // to maintain the Heap with index and its value
{
	int index;
	float val;
}