package DocSimilarity;

import java.util.ArrayList;

public class Node 
{
	int word1;
	ArrayList<Edge> edges;
}
