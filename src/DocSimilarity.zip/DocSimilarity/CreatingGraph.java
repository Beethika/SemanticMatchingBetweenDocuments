package DocSimilarity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class CreatingGraph
{
	TreeSet<String> dictionary; // unique keyword for each word
	HashMap<String,Integer> dictionaryMap;
	ArrayList<Node> graph; // co-occurrence graph

	// lexicographic ordering of all keywords present in document corpus
	public void renamingWords() throws IOException
	{
		dictionary = new TreeSet<String>();
		String word1,word2;
		String[] paths = {"1.txt", "2.txt", "3.txt", "4.txt", "5.txt", "6.txt", "7.txt", "8.txt", "9.txt", "10.txt", "11.txt", "12.txt", "13.txt", "14.txt"};
	    for(String path: paths)
		{
	    	System.out.println(path);
	    	File inFile = new File(path);      //Reading from file
	    	BufferedReader br = new BufferedReader(new FileReader(inFile));
	    	while (br.ready())
	    	{
	    		StringTokenizer line = new StringTokenizer(br.readLine());
	    		if(line.hasMoreTokens())
	    		{
	    			word1 = line.nextToken();
	    			dictionary.add(word1);
	    		}
	    		if(line.hasMoreTokens())
	    		{
	    			word2 = line.nextToken();
	    			dictionary.add(word2);
	    		}
	    	}
	    	br.close();
	    	System.out.println("size of dict: "+dictionary.size());
		}
	    // write each data point into a file
	    try
	    {

	    	FileWriter writer = new FileWriter("Dictionary.txt", true);
	    	int i=0;
	    	for(String data: dictionary)
	    	{
	    		i++;
	 	   	  	writer.write(i+"\t"+data);
	 	   	  	writer.write("\r\n"); // write new line
	    	}
	    	writer.close();
	    }
	    catch (IOException e)
	    {
	    	e.printStackTrace();
	    }
	    System.out.println(dictionary.size());
	    //System.out.println(dictionary);
	}
	// constructing the co-occurance graph
	public void contructGraph() throws IOException
	{
		//TreeSet<String> t = dictionary;
		dictionaryMap = new HashMap<String,Integer>();
		graph = new ArrayList<Node>();
		int index = 1; 
		for(String s:dictionary)
		{
			dictionaryMap.put(s, index);
			index++;
		}
		// creating node for each word
		for(int i= 0;i<dictionary.size();i++)
		{
			Node n =  new Node();
			n.word1 = i+1;
			n.edges = new ArrayList<Edge>();
			graph.add(n);
		}
		//Scanner sc = new Scanner(new FileReader("14.txt"));
		//sc.useDelimiter("\\s");
		String[] paths = {"1.txt", "2.txt", "3.txt", "4.txt", "5.txt", "6.txt", "7.txt", "8.txt", "9.txt", "10.txt", "11.txt", "12.txt", "13.txt", "14.txt"};
	    for(String path: paths)
		{
	    	System.out.println(path);
		File inFile = new File(path);      //Reading from file
	    BufferedReader br = new BufferedReader(new FileReader(inFile));
	    while (br.ready())
	    {
	    	String w1 = null,w2 = null;
	    	float weight = 0;
	        StringTokenizer line = new StringTokenizer(br.readLine());
	        if(line.hasMoreTokens())
	           	w1 = line.nextToken();
	        if(line.hasMoreTokens())
	           	w2 = line.nextToken();
	        if(line.hasMoreTokens())
	           	weight = Float.parseFloat(line.nextToken());

	        // convert string to integer
			//int word1 = t.headSet(w1).size(); // to retrieve the index from a treeset
			//int word2 = t.headSet(w2).size();
	        int word1 = dictionaryMap.get(w1);
	        int word2 = dictionaryMap.get(w2);
	        /*---------- adding these words to graph---------*/
			// adding word2 in adjacency list of word1
			int index1 = word1;
			Node n1 = graph.get((int) index1-1);
			Edge e1 = new Edge();
			e1.word2 = word2;
			e1.weight = weight;
			n1.edges.add(e1);
			graph.set((int) index1-1, n1);
			// adding word1 in adjacency list of word2
			int index2 = word2;
			Node n2 = graph.get((int) index2-1);
			Edge e2 = new Edge();
			e2.word2 = word1;
			e2.weight = weight;
			n2.edges.add(e2);
			graph.set((int) index2-1, n2);
		}
		br.close();
		}
		FileWriter writer = new FileWriter("Co-OccurrenceGraph.txt", true);
		for(Node n: graph)
		{
			writer.write(String.valueOf(n.word1));
			writer.write("\r\n");
			//System.out.print("EdgeList:  ");
			int i=0;
			for(Edge e:n.edges)
			{
				if(i==0)
				{
					writer.write("{"+e.word2+":\t"+e.weight);
					i++;
				}
				else
					writer.write(",\t"+e.word2+":\t"+e.weight);
			}

			writer.write("}\r\n");
		}
		writer.close();
	}
	public static void main(String args[]) throws IOException
	{
		CreatingGraph ob = new CreatingGraph();
		ob.renamingWords();
		ob.contructGraph();
	}
}
