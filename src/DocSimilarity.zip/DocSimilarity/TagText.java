package DocSimilarity;

import java.util.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.io.FileUtils;
import edu.stanford.nlp.tagger.maxent.MaxentTagger;
/**
 * @author ma75
 *
 */
public class TagText{
	String processedDataDestination=null;
    String mappingFileDestination=null;
    String taggedReviewsPath=null;
	String filename=null;
	File mapFile=null;
	File reviewFile=null;
	File tempFile=null;
	File resultFile=null;
	FileReader filereader=null;
	FileWriter filewriter=null;
	BufferedReader breader=null;
	BufferedReader breader1=null;
	BufferedWriter bwriter=null;
	MaxentTagger tagger=null;
	List<String> adjective= new ArrayList<String>();
	List<String> noun= new ArrayList<String>();
	boolean fileStatus=true;//file contains any entries
	List<String[]> entries= new ArrayList<String[]>();
	HashMap<String, Integer> adj_pair = new HashMap<String, Integer>();
	HashMap<String, Integer> adjNoun_pair = new HashMap<String, Integer>();
	HashMap<String, String> temp = new HashMap<String, String>();
	HashMap<String, String> temp1 = new HashMap<String, String>();
	HashMap<String,Integer> adjCount=new HashMap<String,Integer>();
	HashMap<String,Integer> tempadjCount=new HashMap<String,Integer>();
	int reviewCountLimit=0;
	String taggedText[];
	String taggedAdj[];
	String pre1[];
	String pre2[];
	int CoOccurenceCount,i,j=0;
	int temp_reviewCount=0;
	String adj;
	
	public void occurrenceOfTermInCluster(String word)
	{
		HashMap<String,Integer> termOccurrence=new HashMap<String,Integer>();
		String adjective=null;
		try {
			/*breader=new BufferedReader(new FileReader("/home/pratap/OSL1/userevaluationcooccurrences/TopicExpansionResults/initial_topic_cultsers/"+word+".txt"));
			*/
			//temp for coconut oil only
			breader=new BufferedReader(new FileReader("/home/pratap/OSL1/cookiesonly/TopicExpansionResults/initial_topic_cultsers/"+word+".txt"));
			//temp ends here
			adjective=breader.readLine();
			while(adjective!=null)
			{
				if(!adjective.equalsIgnoreCase("********************"+word+"*********************"))
				{
					if(termOccurrence.containsKey(adjective))
					{
						termOccurrence.put(adjective,termOccurrence.get(adjective)+1 );
					}
					else
					{
						termOccurrence.put(adjective,1 );
					}
				}
				adjective=breader.readLine();
			}
			breader.close();
			/*
			//writeToFile(termOccurrence,"/home/pratap/OSL1/userevaluationcooccurrences/TopicExpansionResults/initial_topic_cultsers/"+word+".csv",-1);
			 * for all products
			 */
			
			//for coconut oil only
			writeToFile(termOccurrence,"/home/pratap/OSL1/cookiesonly/TopicExpansionResults/initial_topic_cultsers/"+word+".csv",-1);
			//ends coconut oil only 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			//System.out.println(termOccurrence.entrySet());
	}
	public void initialiseFilePath(String processedDataDestination,String mappingFileDestination,String taggedReviewsPath)
	{
		mapFile=new File( mappingFileDestination+"FoodDB"+".csv");
		this.processedDataDestination=processedDataDestination;
		this.mappingFileDestination=mappingFileDestination;
		this.taggedReviewsPath=taggedReviewsPath;
		try {
			breader1=new BufferedReader(new FileReader(mapFile));
			tagger = new MaxentTagger("taggers/bidirectional-distsim-wsj-0-18.tagger");// initialise tagger for tagging the reviews
			savetaggedOutput();
			//nounOrAdjective();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(ClassNotFoundException cne)
		{
			cne.printStackTrace();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
		
	}
	/*--------------------------------*/
	public void writeToFileAdjectiveandNounOccurrenceOfWord(HashMap<String, Integer> adjective,HashMap<String, Integer> noun,String path)
	{
		try {
			filewriter=new FileWriter(path);
			
			filewriter.write("Word"+","+"NounOccurrence"+","+"AdjectiveOccurrence"+"\n");
			
			for(Map.Entry entry : noun.entrySet())
		 	{
				//System.out.println(entry.getKey());
	 			if(adjective.get(entry.getKey())!=null)
	 			filewriter.write(entry.getKey()+","+entry.getValue()+","+adjective.get(entry.getKey())+"\n");
	 			else
	 				filewriter.write(entry.getKey()+","+entry.getValue()+","+0+"\n");
	 			
	 		}
	
			filewriter.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/*---------------------------------*/
	// write co-occurrence of noun-noun/adjective-adjective/adjective-noun with their co-occurrence count in csv file
	public void writeToFile(HashMap<String, Integer> adj_pair,String path,int type)
	{
		try {
			filewriter=new FileWriter(path);
			if(type==1)
			filewriter.write("Adjective_1"+"\t"+"Adjective_2"+"\t"+"count"+"\n");
			else if(type==2)
			filewriter.write("Noun_1"+"\t"+"Noun_2"+"\t"+"count"+"\n");
			else if(type==3)
			filewriter.write("Adj"+"\t"+"Noun"+"\t"+"count"+"\n");
			else
				filewriter.write("Term"+","+"ClusterCount"+"\n");
			for(Map.Entry entry : adj_pair.entrySet())
		 	{
	 			
	 			filewriter.write(entry.getKey()+","+entry.getValue()+"\n");
	 		}
	
			filewriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	// for two words find the number of documents which contain both the words
	public int getCount(String s1,String s2)
	{
		//System.out.println(s1+"And"+s2);
		int count=0;
		
		 pre1=s1.split(" ");
		 pre2=s2.split(" ");
			for(int i=0;i< pre1.length;i++)
			{
				for(int j=0;j<pre2.length;j++)
				{
					if(pre1[i].equals(pre2[j]))
						{
							count+=1;
							break;
						}
					else if(Integer.parseInt(pre1[i])< Integer.parseInt(pre2[j]))
					{
						break;
					}
				}
			}
		
		
		return count;
	}
	/*---------------------------------------------------------------------*/
	public void nounOrAdjective()
	{
		String fileContent=null;
		String lineContent="";
		String lineparts[]=null;
		String tempPath="";
		HashMap <String,Integer> adjective=new HashMap<String,Integer>();
		HashMap <String,Integer> noun=new HashMap<String,Integer>();
		
		int reviewCount=0;
		try {
			lineContent=breader1.readLine();
			lineContent=breader1.readLine();
			//System.out.println(lineContent);
			adjective.clear();
			noun.clear();
			while(lineContent!=null)
		
			{
			 	temp_reviewCount=1;
				lineparts=lineContent.split("\t");
				//System.out.println(lineparts[0]);
				reviewCount=Integer.parseInt(lineparts[2]);
				System.out.println(lineparts[0] +" "+lineparts[1]+"  "+lineparts[2]);
				adjective.clear();
				noun.clear();
				//reviewCountLimit+=reviewCount;
				// process all reviews for one product
				while(temp_reviewCount<=reviewCount)
				{
				
					taggedText=null;
					taggedAdj=null;
					tempPath= taggedReviewsPath+"/"+lineparts[1]+"/"+"review_";
					reviewFile=new File(tempPath+Integer.toString(temp_reviewCount)+".txt");
					fileContent=FileUtils.readFileToString(reviewFile);
					//System.out.println(fileContent);
					taggedText=fileContent.split(" ");
				
					//System.out.println(taggedText);
					for(int i=0;i<taggedText.length;i++)
					{
						//System.out.println(taggedText);
						// identify adjectives
						if(taggedText[i].contains("/JJ") || taggedText[i].contains("/JJR") || taggedText[i].contains("/JJS"))
						{
						//System.out.println(s[i]);
						 
							taggedAdj=taggedText[i].split("(/JJ){1,1}R{0,1}S{0,1}");
							taggedAdj[0]=taggedAdj[0].toLowerCase();
							if(taggedAdj[0].length()==1 || taggedAdj[0].length()==2)
							continue;
							// if adjective is already present in list
							if(adjective.containsKey(taggedAdj[0]))
							{
									adjective.put(taggedAdj[0],adjective.get(taggedAdj[0])+1);
							}
							// store adjective and corresponding review number in hashmap
							else
							{
							        adjective.put(taggedAdj[0],1);
							}
						//System.out.println(s1[0]);
					     }
					// identify Nouns
					else if(taggedText[i].contains("/NN") || taggedText[i].contains("/NNP") || taggedText[i].contains("/NNPS") || taggedText[i].contains("/NNS"))
					{
						
							taggedAdj=taggedText[i].split("(/NN){1,1}P{0,1}S{0,1}");
							taggedAdj[0]=taggedAdj[0].toLowerCase();
							if(taggedAdj[0].length()==1 || taggedAdj[0].length()==2 )
							continue;
							//System.out.println(taggedAdj[0]);
							if(noun.containsKey(taggedAdj[0]))
							{
								//System.out.println("inside if");
								
									noun.put(taggedAdj[0],noun.get(taggedAdj[0])+1);
							}
							else
							{
								
									noun.put(taggedAdj[0],1);
							}
					
					}//END ELSE IF*/
					else
					{
						
					}
				
				//System.out.println(count_occurence.size());
				//System.out.println(adjective.size());
			}//END FOR
				temp_reviewCount++;
				//System.out.println(temp_reviewCount);
		}//END WHILE
				
			//modify path accordingly
			/* All products only
			writeToFileAdjectiveandNounOccurrenceOfWord(adjective,noun,"/home/pratap/OSL1/userevaluationcooccurrences/Processed_Data/TaggedReviews/NounToAdjective/"+lineparts[1]+".csv");
			//ends all products code. Keep the marker comments.
			*/
			
			//coconut oil only	
			writeToFileAdjectiveandNounOccurrenceOfWord(adjective,noun,"/home/pratap/OSL1/cookiesonly/Processed_Data/TaggedReviews/NounToAdjective/"+lineparts[1]+".csv");
			//coconut oil only.
			
			//writeToFile(adjCount,"/home/ma75/Desktop/"+lineparts[1]+"_Count.csv",0);
			lineContent=breader1.readLine();
			
	}
			//breader1.close();
}//try end
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		
	}
	
	/*---------------------------------------------------------------------*/
	/*----------------------For debug purpose------------------------------*/
	public void findGoodbad(String processedDataDestination,String mappingFileDestination) throws IOException   //skipped for the moment
	{
		
		String fileContent=null;
		String lineContent="";
		String lineparts[]=null;
		String tempPath="";
		int reviewCount=0;
		try {
			mapFile=new File( mappingFileDestination+"FoodDB"+".csv");
			breader1=new BufferedReader(new FileReader(mapFile));
			// initialise taggger for tagging the reviews
			//tagger = new MaxentTagger("taggers/bidirectional-distsim-wsj-0-18.tagger");
			lineContent=breader1.readLine();
			lineContent=breader1.readLine();
			//System.out.println(lineContent);
			while(lineContent!=null)
		
			{
			 	temp_reviewCount=1;
				lineparts=lineContent.split("\t");
				//System.out.println(lineparts[0]);
				reviewCount=Integer.parseInt(lineparts[2]);
				System.out.println(lineparts[0] +" "+lineparts[1]+"  "+lineparts[2]);
				
				//reviewCountLimit+=reviewCount;
				while(temp_reviewCount<=reviewCount)
				{
				
					taggedText=null;
					taggedAdj=null;
					tempPath= processedDataDestination+"/"+lineparts[1]+"_review_";
					reviewFile=new File(tempPath+Integer.toString(temp_reviewCount)+".txt");
					fileContent=FileUtils.readFileToString(reviewFile);
					if(fileContent.contains("good") && fileContent.contains("bad"))
					{
//						filewriter=new FileWriter("/home/ma75/Desktop/GoodBad/"+lineparts[1]+"_review_"+Integer.toString(temp_reviewCount)+".txt");
						filewriter=new FileWriter("/home/pratap/OSL1/userevaluationcooccurrences/GoodBad/"+lineparts[1]+"_review_"+Integer.toString(temp_reviewCount)+".txt");
						filewriter.write(fileContent);
						filewriter.close();
					}
					temp_reviewCount++;
				}
				lineContent=breader1.readLine();
			}
		}
			catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				breader1.close();
			}
			
	}
	/*------------------------------------------------------------------------------*/
	
	
	public void sentenceLevelTagging()
	{
		String fileContent=null;
		String lineContent="";
		String lineparts[]=null;
		String sentences[]=null;
		String contentOfSentence=null;
		String tempPath="";
		int filecount=0;
		int reviewCount=0;
		try {
					
			lineContent=breader1.readLine();
			lineContent=breader1.readLine();
			//System.out.println(lineContent);
			while(lineContent!=null)
		
			{
			 	temp_reviewCount=1;
				lineparts=lineContent.split("\t");
				//System.out.println(lineparts[0]);
				reviewCount=Integer.parseInt(lineparts[2]);
				System.out.println(lineparts[0] +" "+lineparts[1]+"  "+lineparts[2]);
				adjective.clear();
				temp.clear();
				adj_pair.clear();
				adjCount.clear();
				//reviewCountLimit+=reviewCount;
				// process all reviews for one product
				while(temp_reviewCount<=reviewCount)
				{
				
					taggedText=null;
					taggedAdj=null;
					tempPath= processedDataDestination+"/"+lineparts[1]+"_review_";
					reviewFile=new File(tempPath+Integer.toString(temp_reviewCount)+".txt");
					fileContent=FileUtils.readFileToString(reviewFile);
					sentences=fileContent.split(".");
					//System.out.println(fileContent);
					// tagger tag the whole review
				for(int sentenceNumber=0;sentenceNumber<sentences.length;sentenceNumber++)
				{
					contentOfSentence=tagger.tagString(fileContent);
					//System.out.println(fileContent);
					taggedText=contentOfSentence.split(" ");
				
					//System.out.println(taggedText);
								for(int i=0;i<taggedText.length;i++)
								{
						//System.out.println(taggedText);
						// identify adjectives
										if(taggedText[i].contains("/JJ") || taggedText[i].contains("/JJR") || taggedText[i].contains("/JJS"))
										{
						//System.out.println(s[i]);
						 
												taggedAdj=taggedText[i].split("(/JJ){1,1}R{0,1}S{0,1}");
												taggedAdj[0]=taggedAdj[0].toLowerCase().trim();
												if(taggedAdj[0].length()==1 || taggedAdj[0].length()==2)
													continue;
												// if adjective is already present in list
												 if(temp.containsKey(taggedAdj[0]))
												 {
							
													 	//System.out.println("inside if");
													 	// check occurrence of adjective in same review more than once 
													 if(!temp.get(taggedAdj[0]).contains(String.valueOf(sentenceNumber)))
													 {
								
														 	temp.put(taggedAdj[0],temp.get(taggedAdj[0])+sentenceNumber+" ");
													 }
		
													 adjCount.put(taggedAdj[0],adjCount.get(taggedAdj[0])+1);
												 }
												 // store adjective and corresponding review number in hashmap
												 else
												 {
													 adjCount.put(taggedAdj[0],1);
													 adjective.add(taggedAdj[0]);
													 temp.put(taggedAdj[0],Integer.toString(sentenceNumber)+" ");
							
												 }
						//System.out.println(s1[0]);
										}
													
							//System.out.println(s1[0]);
							}// END INNER FOR
					}//END OUTER FOR
						
								Collections.sort(adjective);
								temp_reviewCount++;
				}// END INNER WHILE
				
				//System.out.println(temp_reviewCount);
		}//END WHILE
				Collections.sort(adjective);
			// find co-occurrence of adj-noun
			 		for(i=0;i<adjective.size();i++)
				 	{
				 		 CoOccurenceCount=0;
				 		 adj=adjective.get(i);
			 		for( j=i+1;j<adjective.size();j++)
			 		{
			 			CoOccurenceCount=getCount(temp.get(adj),temp.get(adjective.get(j)));
			 			if(CoOccurenceCount==0)
			 				continue;
			 			
			 				adj_pair.put(adjective.get(i)+"\t"+adjective.get(j),CoOccurenceCount);
			 		
			 		}
			 	
			 	}
			//modify path accordingly. For all products
			//writeToFile(adj_pair,"/home/pratap/OSL1/userevaluationcooccurrences/"+lineparts[1]+"_Adj.csv",1);
			//writeToFile(adjCount,"/home/pratap/OSL1/userevaluationcooccurrences/"+lineparts[1]+"_Count.csv",0);
			 		
			//For coconut oil only
	 		writeToFile(adj_pair,"/home/pratap/OSL1/cookiesonly/"+lineparts[1]+"_Adj.csv",1);
			writeToFile(adjCount,"/home/pratap/OSL1/cookiesonly/"+lineparts[1]+"_Count.csv",0);
			//Ends coconut oil only
			lineContent=breader1.readLine();
		 	
	
			breader1.close();
		}
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
}
		
		/* save tagged output*/
	public void savetaggedOutput()
	{
		String fileContent=null;
		String lineContent="";
		String lineparts[]=null;
		
		String tempPath="";
		int reviewCount=0;
		try {
			
			// initialise tagger for tagging the reviews
			
			lineContent=breader1.readLine();
			lineContent=breader1.readLine();
			
			//System.out.println(lineContent);
				while(lineContent!=null)
				{
					temp_reviewCount=1;
					lineparts=lineContent.split("\t");
					reviewCount=Integer.parseInt(lineparts[2]);
					new File("/home/pratap/OSL1/userevaluationcooccurrences/TaggedReviews/FoodsModified/"+lineparts[1]).mkdir();
					System.out.println(lineparts[0] +" "+lineparts[1]+"  "+lineparts[2]);
					
					//reviewCountLimit+=reviewCount;
					// process all reviews for one product
					while(temp_reviewCount<=reviewCount)
					{
					
						taggedText=null;
						taggedAdj=null;
						tempPath= processedDataDestination+"/"+lineparts[1]+"/review_";
						reviewFile=new File(tempPath+Integer.toString(temp_reviewCount)+".txt");
						fileContent=FileUtils.readFileToString(reviewFile);
						//System.out.println(fileContent);
						// tagger tag the whole review
						fileContent=tagger.tagString(fileContent);/* tag the review*/
				        filewriter=new FileWriter(new File("/home/pratap/OSL1/userevaluationcooccurrences/TaggedReviews/FoodsModified/"+lineparts[1]+"/review_"+Integer.toString(temp_reviewCount)+".txt"));
				        filewriter.write(fileContent);
				        temp_reviewCount++;
				        filewriter.close();
					}
					
					lineContent=breader1.readLine();
		       }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	/*--------------Tag(Adj,Noun) using POSTagger-----------------*/
	public void tagWords(String processedDataDestination,String mappingFileDestination) throws IOException
	{
		String fileContent=null;
		String lineContent="";
		String lineparts[]=null;
		String tempPath="";
		
		int reviewCount=0;
		try {
			mapFile=new File( mappingFileDestination+"FoodDB1"+".csv");
			breader1=new BufferedReader(new FileReader(mapFile));
			// initialise tagger for tagging the reviews
			tagger = new MaxentTagger("taggers/bidirectional-distsim-wsj-0-18.tagger");
			lineContent=breader1.readLine();
			lineContent=breader1.readLine();
			//System.out.println(lineContent);
			while(lineContent!=null)
		
			{
			 	temp_reviewCount=1;
				lineparts=lineContent.split("\t");
				//System.out.println(lineparts[0]);
				reviewCount=Integer.parseInt(lineparts[2]);
				System.out.println(lineparts[0] +" "+lineparts[1]+"  "+lineparts[2]);
				adjective.clear();
				temp.clear();
				adj_pair.clear();
				adjCount.clear();
				//reviewCountLimit+=reviewCount;
				// process all reviews for one product
				while(temp_reviewCount<=reviewCount)
				{
				
					taggedText=null;
					taggedAdj=null;
					tempPath= processedDataDestination+"/"+lineparts[1]+"_review_";
					reviewFile=new File(tempPath+Integer.toString(147)+".txt");
					fileContent=FileUtils.readFileToString(reviewFile);
					//System.out.println(fileContent);
					// tagger tag the whole review
					fileContent=tagger.tagString(fileContent);
					/***************************************/
					//sentences=fileContent.split(".");
					
					/***************************************/
				
					
					System.out.println(fileContent);
					System.exit(0);
					taggedText=fileContent.split(" ");
				
					//System.out.println(taggedText);
					for(int i=0;i<taggedText.length;i++)
					{
						//System.out.println(taggedText);
						// identify adjectives
						if(taggedText[i].contains("/JJ") || taggedText[i].contains("/JJR") || taggedText[i].contains("/JJS"))
					{
						//System.out.println(s[i]);
						 
						taggedAdj=taggedText[i].split("(/JJ){1,1}R{0,1}S{0,1}");
						taggedAdj[0]=taggedAdj[0].toLowerCase();
						if(taggedAdj[0].length()==1 || taggedAdj[0].length()==2)
							continue;
						// if adjective is already present in list
						if(temp.containsKey(taggedAdj[0]))
						{
							
							//System.out.println("inside if");
							// check occurrence of adjective in same review more than once 
							if(!temp.get(taggedAdj[0]).contains(String.valueOf(temp_reviewCount)))
							{
								
								temp.put(taggedAdj[0],temp.get(taggedAdj[0])+temp_reviewCount+" ");
							}
		
							adjCount.put(taggedAdj[0],adjCount.get(taggedAdj[0])+1);
						}
						// store adjective and corresponding review number in hashmap
						else
						{
							adjCount.put(taggedAdj[0],1);
							adjective.add(taggedAdj[0]);
							temp.put(taggedAdj[0],Integer.toString(temp_reviewCount)+" ");
							
						}
						//System.out.println(s1[0]);
					}
					// identify Nouns
				/*	else if(taggedText[i].contains("/NN") || taggedText[i].contains("/NNP") || taggedText[i].contains("/NNPS") || taggedText[i].contains("/NNS"))
					{
						
							taggedAdj=taggedText[i].split("(/NN){1,1}P{0,1}S{0,1}");
							taggedAdj[0]=taggedAdj[0].toLowerCase();
							if(taggedAdj[0].length()==1 || taggedAdj[0].length()==2 )
							continue;
							//System.out.println(taggedAdj[0]);
							if(temp1.containsKey(taggedAdj[0]))
							{
								//System.out.println("inside if");
								if(!temp1.get(taggedAdj[0]).contains(String.valueOf(temp_reviewCount)))
								{
							
									temp1.put(taggedAdj[0],temp1.get(taggedAdj[0])+temp_reviewCount+" ");
								}
	
		
							}
							else
							{
									noun.add(taggedAdj[0]);
									temp1.put(taggedAdj[0],Integer.toString(temp_reviewCount)+" ");
						
							}
					
					}//END ELSE IF*/
				
				
				//System.out.println(count_occurence.size());
				//System.out.println(adjective.size());
			}
				temp_reviewCount++;
				//System.out.println(temp_reviewCount);
		}//END WHILE
				Collections.sort(adjective);
			// find co-occurrence of adj-noun
			 		for(i=0;i<adjective.size();i++)
				 	{
				 		 CoOccurenceCount=0;
				 		 adj=adjective.get(i);
			 		for( j=i+1;j<adjective.size();j++)
			 		{
			 			CoOccurenceCount=getCount(temp.get(adj),temp.get(adjective.get(j)));
			 			if(CoOccurenceCount==0)
			 				continue;
			 			
			 				adj_pair.put(adjective.get(i)+"\t"+adjective.get(j),CoOccurenceCount);
			 		
			 		}
			 	
			 	}
			//modify path accordingly. For all products
			//writeToFile(adj_pair,"/home/pratap/OSL1/userevaluationcooccurrences/"+lineparts[1]+"_Adj.csv",1);
			//writeToFile(adjCount,"/home/pratap/OSL1/userevaluationcooccurrences/"+lineparts[1]+"_Count.csv",0);
			//Ends all products
			 		
			//for coconutoilonly. Remove if cluttering
			writeToFile(adj_pair,"/home/pratap/OSL1/cookiesonly/"+lineparts[1]+"_Adj.csv",1);
			writeToFile(adjCount,"/home/pratap/OSL1/cookiesonly/"+lineparts[1]+"_Count.csv",0);
			//ends coconutoilonly
			
			
			lineContent=breader1.readLine();
		 	
	}
}//try end
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			breader1.close();
		}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//breader.close();
		}
		
	}

    public static void main(String[] args) throws IOException  {
    	TagText tt=new TagText();
    	//SupportFunctions supportFunctions=new SupportFunctions();
    	//FindNgram findNgram=new FindNgram("/media/ma75/01CF1BED458C85B0/Osl_Lab/Processed_Data/TaggedReviews/FoodsModified/","/media/ma75/01CF1BED458C85B0/Osl_Lab/Neo4j/FoodDB"+".csv","/media/ma75/01CF1BED458C85B0/Osl_Lab/Processed_Data/TaggedReviews/Trigrams/");
    	/*
    	//FindNgram findNgram=new FindNgram("/home/pratap/OSL1/userevaluationcooccurrences/TaggedReviews","/home/pratap/OSL1/userevaluationcooccurrences/FoodDB"+".csv","/home/pratap/OSL1/userevaluationcooccurrences/Output/");
    	//This line is for running code on all products. Dont remove this marker comment even after that.
    	 */
    	
    	//This is for coconut oil only. Comment this if running for all products
    	FindNgram findNgram=new FindNgram("/home/pratap/OSL1/cookiesonly/TaggedReviews","/home/pratap/OSL1/cookiesonly/FoodDB"+".csv","/home/pratap/OSL1/cookiesonly/Output/");
    	//Coconut oil only block ends here
    	findNgram.readMappingFile();
    	
    	//supportFunctions.fileOperations("/media/ma75/01CF1BED458C85B0/Osl_Lab/Processed_Data/TaggedReviews/WordstageedAsAdjectiveAndNoun/","/media/ma75/01CF1BED458C85B0/Osl_Lab/Neo4j/FoodDB"+".csv","/media/ma75/01CF1BED458C85B0/Osl_Lab/Processed_Data/TaggedReviews/WordstageedAsAdjectiveAndNoun/");
    	//tt.initialiseFilePath("/media/ma75/01CF1BED458C85B0/Osl_Lab/Processed_Data/Reviews/FoodsModified","/media/ma75/01CF1BED458C85B0/Osl_Lab/Neo4j/","/media/ma75/01CF1BED458C85B0/Osl_Lab/Processed_Data/TaggedReviews/FoodsModified/");
    		
    	//tt.tagWords("/media/ma75/01CF1BED458C85B0/Osl_Lab/Processed_Data/Foods/","/media/ma75/01CF1BED458C85B0/Osl_Lab/Neo4j/");
    		//tt.findGoodbad("/media/ma75/01CF1BED458C85B0/Osl_Lab/Processed_Data/Foods/","/media/ma75/01CF1BED458C85B0/Osl_Lab/Neo4j/");
		// tt.getAdjectives();
    	//tt.savetaggedOutput();
    	//tt.occurrenceOfTermInCluster("hard");

	}

}
